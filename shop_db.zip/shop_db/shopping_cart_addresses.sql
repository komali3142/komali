-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: shopping_cart
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `line1` varchar(255) NOT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country_code` char(2) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `is_default_billing` tinyint(1) NOT NULL DEFAULT '0',
  `is_default_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_addresses_user` (`user_id`),
  KEY `idx_addresses_country_postal` (`country_code`,`postal_code`),
  CONSTRAINT `fk_addresses_user` FOREIGN KEY (`user_id`) REFERENCES `user_tbl` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,NULL,'Recipient 1','1 Main Street',NULL,'Hyderabad','Telangana','500001','IN','+91-9000000001',1,0,'2025-12-25 17:58:27'),(2,NULL,'Recipient 2','2 Main Street',NULL,'Hyderabad','Telangana','500002','IN','+91-9000000002',0,1,'2025-12-25 17:58:27'),(3,NULL,'Recipient 3','3 Main Street',NULL,'Hyderabad','Telangana','500003','IN','+91-9000000003',1,0,'2025-12-25 17:58:27'),(4,NULL,'Recipient 4','4 Main Street',NULL,'Hyderabad','Telangana','500004','IN','+91-9000000004',0,1,'2025-12-25 17:58:27'),(5,NULL,'Recipient 5','5 Main Street',NULL,'Hyderabad','Telangana','500005','IN','+91-9000000005',1,0,'2025-12-25 17:58:27'),(6,NULL,'Recipient 6','6 Main Street',NULL,'Hyderabad','Telangana','500006','IN','+91-9000000006',0,1,'2025-12-25 17:58:27'),(7,NULL,'Recipient 7','7 Main Street',NULL,'Hyderabad','Telangana','500007','IN','+91-9000000007',1,0,'2025-12-25 17:58:27'),(8,NULL,'Recipient 8','8 Main Street',NULL,'Hyderabad','Telangana','500008','IN','+91-9000000008',0,1,'2025-12-25 17:58:27'),(9,NULL,'Recipient 9','9 Main Street',NULL,'Hyderabad','Telangana','500009','IN','+91-9000000009',1,0,'2025-12-25 17:58:27'),(10,NULL,'Recipient 10','10 Main Street',NULL,'Hyderabad','Telangana','500010','IN','+91-9000000010',0,1,'2025-12-25 17:58:27'),(11,NULL,'Recipient 11','11 Main Street',NULL,'Hyderabad','Telangana','500011','IN','+91-9000000011',1,0,'2025-12-25 17:58:27'),(12,NULL,'Recipient 12','12 Main Street',NULL,'Hyderabad','Telangana','500012','IN','+91-9000000012',0,1,'2025-12-25 17:58:27'),(13,NULL,'Recipient 13','13 Main Street',NULL,'Hyderabad','Telangana','500013','IN','+91-9000000013',1,0,'2025-12-25 17:58:27'),(14,NULL,'Recipient 14','14 Main Street',NULL,'Hyderabad','Telangana','500014','IN','+91-9000000014',0,1,'2025-12-25 17:58:27'),(15,NULL,'Recipient 15','15 Main Street',NULL,'Hyderabad','Telangana','500015','IN','+91-9000000015',1,0,'2025-12-25 17:58:27'),(16,NULL,'Recipient 16','16 Main Street',NULL,'Hyderabad','Telangana','500016','IN','+91-9000000016',0,1,'2025-12-25 17:58:27'),(17,NULL,'Recipient 17','17 Main Street',NULL,'Hyderabad','Telangana','500017','IN','+91-9000000017',1,0,'2025-12-25 17:58:27'),(18,NULL,'Recipient 18','18 Main Street',NULL,'Hyderabad','Telangana','500018','IN','+91-9000000018',0,1,'2025-12-25 17:58:27'),(19,NULL,'Recipient 19','19 Main Street',NULL,'Hyderabad','Telangana','500019','IN','+91-9000000019',1,0,'2025-12-25 17:58:27'),(20,NULL,'Recipient 20','20 Main Street',NULL,'Hyderabad','Telangana','500020','IN','+91-9000000020',0,1,'2025-12-25 17:58:27'),(21,NULL,'Recipient 21','21 Main Street',NULL,'Hyderabad','Telangana','500021','IN','+91-9000000021',1,0,'2025-12-25 17:58:27'),(22,NULL,'Recipient 22','22 Main Street',NULL,'Hyderabad','Telangana','500022','IN','+91-9000000022',0,1,'2025-12-25 17:58:27'),(23,NULL,'Recipient 23','23 Main Street',NULL,'Hyderabad','Telangana','500023','IN','+91-9000000023',1,0,'2025-12-25 17:58:27'),(24,NULL,'Recipient 24','24 Main Street',NULL,'Hyderabad','Telangana','500024','IN','+91-9000000024',0,1,'2025-12-25 17:58:27'),(25,NULL,'Recipient 25','25 Main Street',NULL,'Hyderabad','Telangana','500025','IN','+91-9000000025',1,0,'2025-12-25 17:58:27'),(26,NULL,'Recipient 26','26 Main Street',NULL,'Hyderabad','Telangana','500026','IN','+91-9000000026',0,1,'2025-12-25 17:58:27');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-25 18:07:18
