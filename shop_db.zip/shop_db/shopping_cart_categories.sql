-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: shopping_cart
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT NULL,
  `slug` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_categories_parent` (`parent_id`),
  KEY `idx_categories_active` (`is_active`,`sort_order`),
  CONSTRAINT `fk_categories_parent` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,NULL,'electronics-b1','Electronics','Batch 1 - Electronics',1,1,'2025-12-25 16:52:51'),(2,NULL,'fashion-b1','Fashion','Batch 1 - Fashion',1,2,'2025-12-25 16:52:51'),(3,NULL,'home-b1','Home','Batch 1 - Home',1,3,'2025-12-25 16:52:51'),(4,NULL,'kitchen-b1','Kitchen','Batch 1 - Kitchen',1,4,'2025-12-25 16:52:51'),(5,NULL,'beauty-b1','Beauty','Batch 1 - Beauty',1,5,'2025-12-25 16:52:51'),(6,NULL,'grocery-b1','Grocery','Batch 1 - Grocery',1,6,'2025-12-25 16:52:51'),(7,NULL,'sports-b1','Sports','Batch 1 - Sports',1,7,'2025-12-25 16:52:51'),(8,NULL,'books-b1','Books','Batch 1 - Books',1,8,'2025-12-25 16:52:51'),(9,NULL,'electronics-b2','Electronics','Batch 2 - Electronics',0,1,'2025-12-25 16:52:54'),(10,NULL,'fashion-b2','Fashion','Batch 2 - Fashion',1,2,'2025-12-25 16:52:54'),(11,NULL,'home-b2','Home','Batch 2 - Home',0,3,'2025-12-25 16:52:54'),(12,NULL,'kitchen-b2','Kitchen','Batch 2 - Kitchen',1,4,'2025-12-25 16:52:54'),(13,NULL,'beauty-b2','Beauty','Batch 2 - Beauty',0,5,'2025-12-25 16:52:54'),(14,NULL,'grocery-b2','Grocery','Batch 2 - Grocery',1,6,'2025-12-25 16:52:54'),(15,NULL,'sports-b2','Sports','Batch 2 - Sports',0,7,'2025-12-25 16:52:54'),(16,NULL,'books-b2','Books','Batch 2 - Books',1,8,'2025-12-25 16:52:54'),(17,NULL,'electronics-b4','Electronics','Batch 4 - Electronics',0,1,'2025-12-25 16:52:56'),(18,NULL,'fashion-b4','Fashion','Batch 4 - Fashion',0,2,'2025-12-25 16:52:56'),(19,NULL,'home-b4','Home','Batch 4 - Home',0,3,'2025-12-25 16:52:56'),(20,NULL,'kitchen-b4','Kitchen','Batch 4 - Kitchen',0,4,'2025-12-25 16:52:56'),(21,NULL,'beauty-b4','Beauty','Batch 4 - Beauty',0,5,'2025-12-25 16:52:56'),(22,NULL,'grocery-b4','Grocery','Batch 4 - Grocery',0,6,'2025-12-25 16:52:56'),(23,NULL,'sports-b4','Sports','Batch 4 - Sports',0,7,'2025-12-25 16:52:56'),(24,NULL,'books-b4','Books','Batch 4 - Books',0,8,'2025-12-25 16:52:56'),(25,NULL,'electronics-b5','Electronics','Batch 5 - Electronics',1,1,'2025-12-25 16:53:01'),(26,NULL,'fashion-b5','Fashion','Batch 5 - Fashion',1,2,'2025-12-25 16:53:01'),(27,NULL,'home-b5','Home','Batch 5 - Home',1,3,'2025-12-25 16:53:01'),(28,NULL,'kitchen-b5','Kitchen','Batch 5 - Kitchen',1,4,'2025-12-25 16:53:01'),(29,NULL,'beauty-b5','Beauty','Batch 5 - Beauty',1,5,'2025-12-25 16:53:01'),(30,NULL,'grocery-b5','Grocery','Batch 5 - Grocery',1,6,'2025-12-25 16:53:01'),(31,NULL,'sports-b5','Sports','Batch 5 - Sports',1,7,'2025-12-25 16:53:01'),(32,NULL,'books-b5','Books','Batch 5 - Books',1,8,'2025-12-25 16:53:01'),(33,NULL,'electronics-b6','Electronics','Batch 6 - Electronics',1,1,'2025-12-25 16:53:03'),(34,NULL,'fashion-b6','Fashion','Batch 6 - Fashion',0,2,'2025-12-25 16:53:03'),(35,NULL,'home-b6','Home','Batch 6 - Home',1,3,'2025-12-25 16:53:03'),(36,NULL,'kitchen-b6','Kitchen','Batch 6 - Kitchen',0,4,'2025-12-25 16:53:03'),(37,NULL,'beauty-b6','Beauty','Batch 6 - Beauty',1,5,'2025-12-25 16:53:03'),(38,NULL,'grocery-b6','Grocery','Batch  6 - Grocery',0,6,'2025-12-25 16:53:03'),(39,NULL,'sports-b6','Sports','Batch 6 - Sports',1,7,'2025-12-25 16:53:03'),(40,NULL,'books-b6','Books','Batch 6 - Books',0,8,'2025-12-25 16:53:03'),(41,NULL,'electronics-b7','Electronics','Batch 7 - Electronics',1,1,'2025-12-25 16:53:06'),(42,NULL,'fashion-b7','Fashion','Batch 7 - Fashion',1,2,'2025-12-25 16:53:06');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-25 18:07:18
