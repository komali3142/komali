-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: shopping_cart
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `slug` varchar(160) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text,
  `category_id` int DEFAULT NULL,
  `brand` varchar(120) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_products_category_active` (`category_id`,`is_active`),
  FULLTEXT KEY `ftx_products_name_desc` (`name`,`description`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'electronics-b6-smartphone-001','B6 Smartphone Alpha','Batch 6: 6.5\" AMOLED, 8GB RAM, 128GB storage',1,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(2,'electronics-b6-smartphone-002','B6 Smartphone Beta','Batch 6: 6.1\" LCD, 6GB RAM, 128GB, dual SIM',1,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(3,'electronics-b6-laptop-003','B6 Laptop Lite 14','Batch 6: 14\" FHD, i5, 16GB, 512GB SSD',1,'Vertex',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(4,'electronics-b6-laptop-004','B6 Laptop Pro 15','Batch 6: 15.6\" QHD, Ryzen 7, 32GB, 1TB SSD',1,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(5,'electronics-b6-earbuds-005','B6 True Earbuds','Batch 6: ANC, Bluetooth 5.3, 40h battery',1,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(6,'electronics-b6-smartwatch-006','B6 Smartwatch S','Batch 6: AMOLED, SpO2, GPS, 5ATM',1,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(7,'electronics-b6-monitor-007','B6 Monitor 27Q','Batch 6: 27\" QHD, 165Hz, HDR',1,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(8,'fashion-b6-tee-008','B6 Tee Cotton','Batch 6: 100% cotton crew neck tee',2,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(9,'fashion-b6-hoodie-009','B6 Hoodie Fleece','Batch 6: Warm fleece hoodie with zipper',2,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(10,'fashion-b6-jeans-010','B6 Jeans Slim','Batch 6: Slim fit denim, stretch fabric',2,'Fleet',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(11,'fashion-b6-dress-011','B6 Midi Dress','Batch 6: Midi dress with belt, solid color',2,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(12,'fashion-b6-shoes-012','B6 Running Shoes','Batch 6: Lightweight runners, EVA sole',2,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(13,'fashion-b6-cap-013','B6 Cap Classic','Batch 6: Adjustable baseball cap',2,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(14,'home-b6-duvet-014','B6 Duvet Microfiber','Batch 6: All-season microfiber duvet',3,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(15,'home-b6-cushion-015','B6 Cushion Set','Batch 6: 4-piece cushion set, cotton cover',3,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(16,'home-b6-curtains-016','B6 Blackout Curtains','Batch 6: 2-panel blackout curtains',3,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(17,'home-b6-lamp-017','B6 Table Lamp','Batch 6: LED table lamp, adjustable arm',3,'Vertex',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(18,'home-b6-rug-018','B6 Area Rug 5x7','Batch 6: Textured rug, stain-resistant',3,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(19,'home-b6-sheets-019','B6 Bedsheet Set','Batch 6: 1000TC cotton bedsheet set',3,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(20,'kitchen-b6-pan-020','B6 Fry Pan 28cm','Batch 6: Non-stick fry pan, induction base',4,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(21,'kitchen-b6-pot-021','B6 Stock Pot 5L','Batch 6: Stainless steel stock pot',4,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(22,'kitchen-b6-knife-022','B6 Chef Knife 8\"','Batch 6: High-carbon steel, ergonomic handle',4,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(23,'kitchen-b6-board-023','B6 Cutting Board','Batch 6: Bamboo board, juice groove',4,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(24,'kitchen-b6-mixer-024','B6 Mixer 500W','Batch 6: 500W mixer with 3 jars',4,'Fleet',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(25,'kitchen-b6-kettle-025','B6 Electric Kettle','Batch 6: 1.7L kettle, auto shut-off',4,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(26,'beauty-b6-serum-026','B6 Vitamin C Serum','Batch 6: 10% Vitamin C, hyaluronic acid',5,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(27,'beauty-b6-moist-027','B6 Moisturizer','Batch 6: Lightweight daily moisturizer',5,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(28,'beauty-b6-cleanser-028','B6 Gel Cleanser','Batch 6: Sulfate-free gel cleanser',5,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(29,'beauty-b6-shampoo-029','B6 Shampoo Repair','Batch 6: Keratin-infused repair shampoo',5,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(30,'beauty-b6-mask-030','B6 Hair Mask','Batch 6: Deep conditioning hair mask',5,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(31,'beauty-b6-sunscreen-031','B6 Sunscreen SPF50','Batch 6: Broad-spectrum SPF 50 PA++++',5,'Fleet',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(32,'grocery-b6-rice-032','B6 Basmati Rice 5kg','Batch 6: Long-grain basmati rice',6,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(33,'grocery-b6-oil-033','B6 Sunflower Oil','Batch 6: Refined sunflower oil 1L',6,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(34,'grocery-b6-pulses-034','B6 Mixed Pulses 2kg','Batch 6: Protein-rich mixed pulses',6,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(35,'grocery-b6-tea-035','B6 Assam Tea 250g','Batch 6: Premium Assam tea leaves',6,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(36,'grocery-b6-coffee-036','B6 Coffee Roast','Batch 6: Medium roast ground coffee',6,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(37,'grocery-b6-honey-037','B6 Wild Honey 500g','Batch 6: Raw wild honey',6,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(38,'sports-b6-dumbbell-038','B6 Dumbbell 10kg','Batch 6: Neoprene dumbbell pair',7,'Fleet',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(39,'sports-b6-yogamat-039','B6 Yoga Mat Pro','Batch 6: 8mm TPE non-slip yoga mat',7,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(40,'sports-b6-cycle-040','B6 Fitness Cycle','Batch 6: Indoor fitness bike, magnetic res.',7,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(41,'sports-b6-shoes-041','B6 Trail Shoes','Batch 6: Rugged trail running shoes',7,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(42,'sports-b6-bottle-042','B6 Sports Bottle','Batch 6: Insulated steel bottle 1L',7,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(43,'sports-b6-gloves-043','B6 Gym Gloves','Batch 6: Breathable, padded gym gloves',7,'Nova',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(44,'books-b6-novel-044','B6 Novel: Silent Sky','Batch 6: Contemporary fiction novel',8,'Acme',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(45,'books-b6-guide-045','B6 Travel Guide','Batch 6: City travel guide, insider tips',8,'Vertex',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(46,'books-b6-cook-046','B6 Cookbook Home','Batch 6: Easy home-cooking recipes',8,'Fleet',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(47,'books-b6-sci-047','B6 Science Essentials','Batch 6: Intro to modern science',8,'ZenWear',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(48,'books-b6-dev-048','B6 Dev Handbook','Batch 6: Practical software engineering',8,'Pulse',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(49,'books-b6-photo-049','B6 Photography 101','Batch 6: Beginner photography guide',8,'Aero',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(50,'electronics-b6-tablet-050','B6 Tablet 11','Batch 6: 11\" tablet, 8GB/256GB, Wi‑Fi 6',1,'Orion',1,'2025-12-25 17:10:40','2025-12-25 17:10:40'),(51,'fashion-b6-sneakers-051','B6 Sneakers Flex','Batch 6: Flexible sole lifestyle sneakers',2,'Vertex',1,'2025-12-25 17:10:40','2025-12-25 17:10:40');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-25 18:07:15
